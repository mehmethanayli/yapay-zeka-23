# Paket Kurulumları
install.packages("psych")
install.packages("GGally")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("Amelia")

titanic <- read.csv("train.csv" , na.strings = "")
View(titanic)
class(titanic)
str(titanic)
head(titanic)

#Kayıp haritasını çizdirmek için kullanılır.

library(Amelia)
missmap(titanic, col=c("black" , "grey"))

#cabin alanında birçok NA değeri bulunduğu görülmektedir.

library(dplyr)
data.frame= select(titanic, Survived, Pclass, Age, Sex, SibSp,Parch)


#NA verilerin bulunduğu satırların kaldırılması.
data.frame=na.omit(data.frame)

#Verilerin Kontrol Edilmesi
str(data.frame)

data.frame$Survived=factor(data.frame$Survived)
str(data.frame)

data.frame$Pclass=factor(data.frame$Pclass , order=TRUE , levels =c(3,2,1) )
str(data.frame)

#kaldığı sınıfa göre hayatta kalanlar
library(ggplot2)
ggplot(data.frame) + geom_bar(mapping = aes(x=Sex, fill=Survived)) + facet_grid(~Pclass)
